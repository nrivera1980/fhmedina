@extends('adminlte::page')

@section('title', 'FHMEDINA: Administrador')

@section('content_header')
    <h1>Panel principal</h1>
@stop

@section('content')
    <p>Bienvenido a este fabuloso panel de administración.</p>
@stop

@section('css')
    {{-- <link rel="stylesheet" href="/css/admin_custom.css"> --}}
@stop

@section('js')
    <script> console.log('Hi!'); </script>
@stop