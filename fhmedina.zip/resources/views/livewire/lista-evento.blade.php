<div class="d-inline">
    @if ($eventos->count())
        @foreach ($eventos as $evento)
            <div class="w-full">

            </div>
        @endforeach
    @else
        <div class="w-full">
            NOhay eventos registrados...
        </div>
    @endif
    
</div>
