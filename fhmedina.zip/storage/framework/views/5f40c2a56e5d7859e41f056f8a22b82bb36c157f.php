<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <section class="splide" aria-label="Splide Basic HTML Example">
        <div class="splide__track">
              <ul class="splide__list">
                  <li class="splide__slide">
                      <img class="w-full" src="<?php echo e(Storage::url('public/slider/dea017_1_2_banner.jpg')); ?>" alt="">
                  </li>
                  <li class="splide__slide">
                    <img class="w-full" src="<?php echo e(Storage::url('public/slider/dea018_1_2_banner.jpg')); ?>" alt="Second slide">
                  </li>
                  <li class="splide__slide">
                    <img class="w-full" src="<?php echo e(Storage::url('public/slider/eli009_1_2_banner.jpg')); ?>" alt="Third slide">
                  </li>
              </ul>
        </div>
    </section>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('lista-evento')->html();
} elseif ($_instance->childHasBeenRendered('7rYGAwR')) {
    $componentId = $_instance->getRenderedChildComponentId('7rYGAwR');
    $componentTag = $_instance->getRenderedChildComponentTagName('7rYGAwR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7rYGAwR');
} else {
    $response = \Livewire\Livewire::mount('lista-evento');
    $html = $response->html();
    $_instance->logRenderedChild('7rYGAwR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <script>
        document.addEventListener( 'DOMContentLoaded', function() {
            new Splide('.splide', {
                type:"loop",
                perPage:1,
                autoplay:true,
            }).mount();
        } );
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<?php /**PATH D:\laragon\www\fhmedina\resources\views/welcome.blade.php ENDPATH**/ ?>