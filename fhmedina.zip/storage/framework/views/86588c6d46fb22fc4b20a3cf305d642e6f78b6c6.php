<div class="d-inline">
    <?php if($eventos->count()): ?>
        <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="w-full">

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="w-full">
            NOhay eventos registrados...
        </div>
    <?php endif; ?>
    
</div>
<?php /**PATH D:\laragon\www\fhmedina\resources\views/livewire/lista-evento.blade.php ENDPATH**/ ?>