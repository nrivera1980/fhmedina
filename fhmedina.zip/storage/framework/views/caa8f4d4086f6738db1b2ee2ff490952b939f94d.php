

<?php $__env->startSection('title', 'FHMEDINA: Administrador'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Panel principal</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>Bienvenido a este fabuloso panel de administración.</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\fhmedina\resources\views/admin/index.blade.php ENDPATH**/ ?>