<a href="/">
    <img src="<?php echo e(Storage::url('public/img/logotipo.png')); ?>" class="w-20 h-16" alt="">
    
</a>
<?php /**PATH D:\laragon\www\fhmedina\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>