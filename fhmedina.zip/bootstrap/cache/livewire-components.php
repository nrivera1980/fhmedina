<?php return array (
  'lista-evento' => 'App\\Http\\Livewire\\ListaEvento',
  'navigation' => 'App\\Http\\Livewire\\Navigation',
);